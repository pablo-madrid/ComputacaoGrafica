Implementar no OPENGL usando os shaders de vertice e fragmento em arquivos separados (main.c; vertex.s; fragment.s):

*   A inclusão de 2 objetos 3D na cena;
*   Implementar no Shader de Vértice a matriz de rotação para rotacionar os objetos na cena;
*   Aplicar no shader de fragmento a implementação da luz ambiente com coeficiente em 0.3;
*   Comente todas as partes do código explicando cada etada (de maneira objetiva, não descrever o comando);
*   Compactar e enviar os arquivos zip. 